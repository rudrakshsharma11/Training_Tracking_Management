package com.cozentus.TrainingTracking.Service;

public class BatchTeacherCourseService {

}
