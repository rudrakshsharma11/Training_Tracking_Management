package com.cozentus.TrainingTracking.RestController;

public class BatchTeacherCourseRestController {

}
