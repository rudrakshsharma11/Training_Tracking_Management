package com.cozentus.TrainingTracking;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TrainingTrackingApplication {

	public static void main(String[] args) {
		SpringApplication.run(TrainingTrackingApplication.class, args);
	}

}
