package com.cozentus.TrainingTracking.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cozentus.TrainingTracking.Model.BatchTeacherCourse;

public interface BatchTeacherCourseRepository extends JpaRepository<BatchTeacherCourse, Integer> {

}
