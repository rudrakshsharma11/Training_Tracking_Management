package com.cozentus.TrainingTracking;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TrainingTrackingApplicationTests {

	@Test
	void contextLoads() {
	}

}
